/*
Copyright 2016 Centro de Investigación en Tecnoloxías da Información (CITIUS)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package es.usc.citius.scalding2mongo

import cascading.tap.Tap
import com.twitter.scalding._

class MongoSink (val handler: MongoHandler) extends SchemedSource with DelimitedScheme {
  override def createTap(readOrWrite: AccessMode)(implicit mode: Mode): Tap[_, _, _] = {
    mode match {
      // TODO support strict in Local
      case Local(_) => {
        readOrWrite match {
          case Read => throw new java.lang.IllegalArgumentException("Failed to create Mongo tap for read mode (local)")
          case Write => new MongoTap(this.localScheme, handler)
        }
      }
      case hdfsMode @ Hdfs(_, _) => readOrWrite match {
        case Read =>  throw new java.lang.IllegalArgumentException("Failed to create Mongo tap for read mode (hdfs)")
        case Write => new MongoTap(this.hdfsScheme, handler)
      }
      case _ => throw new java.lang.IllegalArgumentException("Failed to create Mongo tap for unknown mode")
    }
  }
}

object MongoSink {
  def apply(handler: MongoHandler) = {
    new MongoSink(handler)
  }
  def apply(host: String, port: Int, db: String, collection: String) = {
    val sas = List(new MongoServerAddress(host, port))
    val h = new DefaultMongoHandler(sas, db, collection)
    new MongoSink(h)
  }
  def apply(data: Tuple4[String, Int, String, String]): MongoSink = apply(data._1, data._2, data._3, data._4)
}

object MongoSinkParser {
  def apply(str : String) = {
    val s = str.split(":");
    (s(0), s(1).toInt, s(2), s(3))
  }
}