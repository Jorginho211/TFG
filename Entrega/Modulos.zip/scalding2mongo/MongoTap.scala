/*
Copyright 2016 Centro de Investigación en Tecnoloxías da Información (CITIUS)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package es.usc.citius.scalding2mongo

import cascading.flow.FlowProcess
import cascading.scheme.Scheme
import cascading.tap.Tap
import cascading.tuple.{TupleEntry, TupleEntryCollector, TupleEntryIterator}
import com.mongodb._

import scala.collection.JavaConversions._

class MongoTap[A, B, C](scheme: Scheme[A, B, C, _, _], handler: MongoHandler) extends Tap[A, B, C](scheme) {

  override def deleteResource(config: A): Boolean = true

  override def resourceExists(config: A): Boolean = true

  override def getModifiedTime(config: A): Long = System.currentTimeMillis();

  override def createResource(config: A): Boolean = true

  override def getIdentifier: String = s"mongo://"+handler.identifier

  override def openForWrite(flowProcess: FlowProcess[A], output: C): TupleEntryCollector = {
    return new MongoTupleCollector(this.handler)
  }

  override def openForRead(flowProcess: FlowProcess[A], input: B): TupleEntryIterator = throw new UnsupportedOperationException("Reading operations from MongoDB are not yet supported.");

  class MongoTupleCollector(handler: MongoHandler) extends TupleEntryCollector {

    override def collect(tupleEntry: TupleEntry) {
      this.handler.handle(tupleEntry);
    }
  }
}

case class MongoServerAddress(val hostname: String, val port: Int)

trait MongoHandler extends java.io.Serializable {
  protected val servers: List[MongoServerAddress]
  @transient
  protected lazy val mMongoClient = new MongoClient(servers.map(s => new ServerAddress(s.hostname, s.port)))

  def getDB(name: String): DB = {
    return mMongoClient.getDB(name);
  }

  def handle(tupleEntry: TupleEntry);

  def identifier: String = "mongo://"+servers.map(_.toString).reduceLeft(_ + "," + _)
}

class DefaultMongoHandler(val mongoServer: List[MongoServerAddress], val databaseName: String, val collectionName: String) extends MongoHandler {

  @transient
  lazy val mCollection: DBCollection = this.getDB(this.databaseName).getCollection(collectionName);

  override def handle(tupleEntry: TupleEntry): Unit = {
    val fields = tupleEntry.getFields();
    val dbo = new BasicDBObject();

    fields.toList.map(f => (f.toString, tupleEntry.getObject(f).toString)).foreach(f => dbo.put(f._1, f._2))

    this.mCollection.insert(dbo);
  }

  override val servers: List[MongoServerAddress] = mongoServer
  override def identifier: String = super.identifier+s"/${databaseName}/${collectionName}"
}
