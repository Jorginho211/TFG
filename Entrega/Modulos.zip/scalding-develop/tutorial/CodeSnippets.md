Please see the [API reference](https://github.com/twitter/scalding/wiki/API-Reference) on the wiki.
