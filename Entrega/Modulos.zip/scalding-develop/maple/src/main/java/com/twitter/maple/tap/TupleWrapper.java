package com.twitter.maple.tap;

import cascading.tuple.Tuple;

public class TupleWrapper {
    public Tuple tuple;
}
